/*
Created		9/15/2017
Modified		10/18/2017
Project		
Model		
Company		
Author		
Version		
Database		Oracle 10g 
*/








































Drop table "SHOPPING_CART"
/
Drop table "ORDERS_LINE"
/
Drop table "CLICK_RECORDS"
/
Drop table "ORDERS"
/
Drop table "STAFF"
/
Drop table "PRODUCT"
/
Drop table "CUSTOMER"
/


-- Create Types section





-- Create Tables section


Create table "CUSTOMER" (
	"CUS_ID" Number(11,0) NOT NULL ,
	"CUS_FNAME" Varchar2 (20) NOT NULL ,
	"CUS_LNAME" Varchar2 (20) NOT NULL ,
	"CUS_USERNAME" Varchar2 (20) NOT NULL ,
	"CUS_PASSWORD" Varchar2 (20) NOT NULL ,
	"CUS_EMAIL" Varchar2 (32) NOT NULL ,
	"CUS_ADDRESS" Varchar2 (128),
	"CUS_PHONE" Number(8,0),
	"CUS_PREF_SWEET" Varchar2 (20) NOT NULL ,
	"CUS_PREF_ORIGIN" Varchar2 (20) NOT NULL ,
	"CUS_CREDIT_CARD_NO" Number(16,0),
	"CUS_DOB" Date NOT NULL ,
primary key ("CUS_ID") 
) 
/

Create table "PRODUCT" (
	"PROD_ID" Number(11,0) NOT NULL ,
	"PROD_NAME" Varchar2 (200) NOT NULL ,
	"PROD_REGION" Varchar2 (20) NOT NULL ,
	"PROD_COUNTRY" Varchar2 (20) NOT NULL ,
	"PROD_PRICE" Number(8,2) NOT NULL ,
	"PROD_VOLUME" Number(11,0) NOT NULL ,
	"PROD_QUANTITY" Number(6,0) NOT NULL ,
	"PROD_DESC" Varchar2 (1000) NOT NULL ,
	"PROD_SWEET" Varchar2 (20) NOT NULL ,
primary key ("PROD_ID") 
) 
/

Create table "STAFF" (
	"STA_ID" Number(11,0) NOT NULL ,
	"STA_FNAME" Varchar2 (20) NOT NULL ,
	"STA_LNAME" Varchar2 (20) NOT NULL ,
	"STA_USERNAME" Varchar2 (20) NOT NULL ,
	"STA_PASSWORD" Varchar2 (20) NOT NULL ,
	"STA_POSITION" Varchar2 (20) NOT NULL ,
	"STA_EMAIL" Varchar2 (32) NOT NULL ,
	"STA_PHONE" Number(8,0) NOT NULL ,
primary key ("STA_ID") 
) 
/

Create table "ORDERS" (
	"ORD_ID" Number(11,0) NOT NULL ,
	"ORD_DATE" Date NOT NULL ,
	"ORD_AMOUNT" Number(10,2) NOT NULL ,
	"ORD_STATUS" Varchar2 (20) NOT NULL ,
	"CUS_ID" Number(11,0) NOT NULL ,
	"STA_ID" Number(11,0) NOT NULL ,
primary key ("ORD_ID") 
) 
/

Create table "CLICK_RECORDS" (
	"CLI_ID" Number(11,0) NOT NULL ,
	"CLI_DATE" Date NOT NULL ,
	"PROD_ID" Number(11,0) NOT NULL ,
primary key ("CLI_ID") 
) 
/

Create table "ORDERS_LINE" (
	"ORD_ID" Number(11,0) NOT NULL ,
	"PROD_ID" Number(11,0) NOT NULL ,
	"ORDL_QUANTITY" Number(2,0) NOT NULL ,
primary key ("ORD_ID","PROD_ID") 
) 
/

Create table "SHOPPING_CART" (
	"CUS_ID" Number(11,0) NOT NULL ,
	"PROD_ID" Number(11,0) NOT NULL ,
	"SHOP_QUANTITY" Number(2,0),
primary key ("CUS_ID","PROD_ID") 
) 
/





-- Create Alternate keys section


-- Create Indexes section



-- Create section for PKs, AKs and Unique constraints, which have to be generated after Indexes



-- Create Foreign keys section

Alter table "ORDERS" add  foreign key ("CUS_ID") references "CUSTOMER" ("CUS_ID") 
/

Alter table "SHOPPING_CART" add  foreign key ("CUS_ID") references "CUSTOMER" ("CUS_ID") 
/

Alter table "CLICK_RECORDS" add  foreign key ("PROD_ID") references "PRODUCT" ("PROD_ID") 
/

Alter table "ORDERS_LINE" add  foreign key ("PROD_ID") references "PRODUCT" ("PROD_ID") 
/

Alter table "SHOPPING_CART" add  foreign key ("PROD_ID") references "PRODUCT" ("PROD_ID") 
/

Alter table "ORDERS" add  foreign key ("STA_ID") references "STAFF" ("STA_ID") 
/

Alter table "ORDERS_LINE" add  foreign key ("ORD_ID") references "ORDERS" ("ORD_ID") 
/


-- Create Object Tables section



-- Create XMLType Tables section



-- Create Procedures section



-- Create Functions section



-- Create Views section



-- Create Sequences section




-- Create Triggers from referential integrity section






















-- Create user Triggers section



-- Create Packages section





-- Create Synonyms section



-- Create Roles section



-- Users Permissions to roles section



-- Roles Permissions section

/* Roles permissions */




-- User Permissions section

/* Users permissions */




-- Create Table comments section


-- Create Attribute comments section


-- After section


